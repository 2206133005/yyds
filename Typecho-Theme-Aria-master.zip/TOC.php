<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="col-mb-12 col-2 kit-hidden-tb"><div id="toc-container"><div id="toc"></div></div></div>